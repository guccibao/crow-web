from flask import Flask, render_template, request, redirect, url_for, flash
import smtplib
import imaplib
import email
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from dotenv import load_dotenv
import os

load_dotenv()

app = Flask(__name__)
app.secret_key = 'your_secret_key'

EMAIL_ADDRESS = os.getenv("EMAIL_ADDRESS")
EMAIL_PASSWORD = os.getenv("EMAIL_PASSWORD")

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/compose", methods=["GET", "POST"])
def compose():
    if request.method == "POST":
        to = request.form["to"]
        subject = request.form["subject"]
        body = request.form["body"]

        msg = MIMEMultipart()
        msg["From"] = EMAIL_ADDRESS
        msg["To"] = to
        msg["Subject"] = subject
        msg.attach(MIMEText(body, "plain"))

        try:
            with smtplib.SMTP("smtp.gmail.com", 587) as server:
                server.starttls()
                server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
                server.send_message(msg)
            flash("Email đã được gửi!", "success")
        except Exception as e:
            flash(f"Lỗi khi gửi email: {str(e)}", "danger")
        return redirect(url_for("index"))

    return render_template("compose.html")

@app.route("/inbox")
def inbox():
    try:
        mail = imaplib.IMAP4_SSL("imap.gmail.com")
        mail.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
        mail.select("inbox")
        _, data = mail.search(None, "ALL")
        email_ids = data[0].split()[-10:]  # lấy 10 email mới nhất
        emails = []

        for eid in reversed(email_ids):
            _, msg_data = mail.fetch(eid, "(RFC822)")
            for response in msg_data:
                if isinstance(response, tuple):
                    msg = email.message_from_bytes(response[1])
                    subject = email.header.decode_header(msg["Subject"])[0][0]
                    if isinstance(subject, bytes):
                        subject = subject.decode()
                    from_ = msg.get("From")
                    emails.append({"from": from_, "subject": subject})

        mail.logout()
        return render_template("inbox.html", emails=emails)

    except Exception as e:
        flash(f"Lỗi khi đọc email: {str(e)}", "danger")
        return redirect(url_for("index"))

if __name__ == "__main__":
    app.run(debug=True)
